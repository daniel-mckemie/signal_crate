#ifndef ENGINE_H
#define ENGINE_H

#include "patch.h"

int start_audio(Patch* patch);

#endif

