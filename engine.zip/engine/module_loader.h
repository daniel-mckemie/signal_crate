#ifndef MODULE_LOADER_H
#define MODULE_LOADER_H

#include "module.h"

Module* load_module(const char* path, float sample_rate);

#endif

