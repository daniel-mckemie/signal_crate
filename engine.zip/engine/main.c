#include <stdio.h>
#include <portaudio.h>
#include "patch.h"
#include "module_loader.h"
#include "engine.h"

int main() {
    Patch patch = {
        .sample_rate = 44100.0f,
        .frame_count = 512,
        .module_count = 0
    };

    // Load modules
    Module* vco = load_module("./modules/vco/vco.dylib", patch.sample_rate);
    Module* moog = load_module("./modules/moog_filter/moog_filter.dylib", patch.sample_rate);

    if (!vco || !moog) {
        fprintf(stderr, "Error loading modules.\n");
        return 1;
    }

    patch.modules[patch.module_count++] = vco;
    // patch.modules[patch.module_count++] = moog;
	if (!vco) {
		fprintf(stderr, "vco module failed to load\n");
		return 1;
	}
	if (!vco->set_param) {
		fprintf(stderr, "vco->set_param is NULL\n");
		return 1;
	}

    // Set hardcoded parameters
    vco->set_param(vco, "freq", 220.0f);       // A3 pitch
    vco->set_param(vco, "amp", 0.8f);          // comfortable volume

    // moog->set_param(moog, "cutoff", 1000.0f);  // low-pass edge
    // moog->set_param(moog, "resonance", 0.5f);  // mellow peak

    // Patch: VCO → Moog
    moog->connect_input(moog, 0, vco->output);

	const PaDeviceInfo* info = Pa_GetDeviceInfo(Pa_GetDefaultOutputDevice());
	printf("Using device: %s\n", info->name);
	printf("Module name: %s\n", patch.modules[0]->name);
	printf("Module output ptr: %p\n", (void*)patch.modules[0]->output);


    // Start audio
    start_audio(&patch);

    printf("Running hardcoded patch: VCO → MoogFilter. Press Enter to stop.\n");
    getchar();

    Pa_Terminate();
    return 0;
}

